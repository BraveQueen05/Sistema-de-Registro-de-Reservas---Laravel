<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="{{ csrf_token() }}">

        <title>Laravel</title>

        <!-- Fonts -->
        <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous"><link href="">

    </head>
    <body>

    <div id="app">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h1>Listado de Reservas</h1>
                </div>
            </div>
            @if(session('status'))
                <div class="alert alert-success" role="alert">
                  {{ session('status') }}
                </div>
            @endif
            @if(session('statusError'))
                <div class="alert alert-danger" role="alert">
                  {{ session('statusError') }}
                </div>
            @endif
            <div style="margin-top: 30px; margin-bottom:30px;">
                <a href="{{ url('/reservas/create') }}" class="btn btn-primary active" role="button" aria-pressed="true">Crear Reserva</a>
            </div>
            <div class="row">
                <div class="col-lg-12">
                
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Código de Reserva</th>
                                <th>Nombre del Cliente</th>
                                <th>Nombre del Anfitrión</th>
                                <th>Número de Clientes</th>
                                <th>Número de Mesa</th>
                                <th>Fecha Creacion</th>
                                <th>Fecha Actualizacion</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($reservas as $reserva)
                                <tr>
                                    <td v-text="cliente.id"> {{ $reserva->id }}</td>
                                    <td v-text="cliente.clienteNombre"> {{ $reserva->clienteNombre }} </td>
                                    <td v-text="cliente.hostNombre"> {{ $reserva->hostNombre }} </td>
                                    <td v-text="cliente.nroClientes	"> {{ $reserva->nroClientes }} </td>
                                    <td v-text="cliente.nroMesa"> {{ $reserva->nroMesa }} </td>
                                    <td v-text="cliente.created_at "> {{ $reserva->created_at }} </td>
                                    <td v-text="cliente.updated_at"> {{ $reserva->updated_at }} </td>
                                    <td>
                                        <form method="POST" action="{{ route('reservas.destroy', $reserva->id) }}">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" class="btn btn-danger">
                                                <i class="fa fa-trash" aria-hidden="true"></i>
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                
                </div>
            </div>
        </div>
    </div>

    </body>
</html>