<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="{{ csrf_token() }}">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous"><link href="">

    </head>
    <body>

    <div id="app">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h1>Registro de Reserva</h1>
                </div>
            </div>
            <form method="POST" action="{{ route('reservas.store')}}">
                @csrf
                <div class="form-group">
                    <label>Nombre del Cliente</label>
                    <input type="text" class="form-control" name="clienteNombre" placeholder="">
                </div>
                <div class="form-group">
                    <label>Nombre del Anfitrión</label>
                    <input type="numbtexter" class="form-control" name="hostNombre" placeholder="">
                </div>
                <div class="form-group" >
                    <label>Número de Personas</label>
                    <select name="nroClientes" class="form-control" name="nroClientes">
                        <option>1</option>
                        <option>2</option>
                        <option>3</option>
                        <option>4</option>
                        <option>5</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-primary mb-2">Confirmar</button>
            </form>

            
        </div>
    </div>

    </body>
</html>