<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Reserve;
use App\Table;

class ReservasController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $reservas = Reserve::all();
        return view("reservas.index", compact('reservas'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view("reservas.create");
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $allTables = Table::where('disponibilidad', 'disponible')->get();
        $quantityForm = request('nroClientes');
        $quantityTable = 100;
        $tableID = 0;

        foreach($allTables as $table){
            if($table->espaciosMesa >= $quantityForm){
                if($table->espaciosMesa <= $quantityTable){
                    $quantityTable = $table->espaciosMesa;
                    $tableID = $table->id;
                }
            }
        }

        if($tableID == 0){
            return redirect('/reservas')->with('statusError', 'No hay mesas disponibles :C'); 
        }

        $newReserva = Reserve::create([
            'clienteNombre' => request('clienteNombre'),
            'hostNombre' => request('hostNombre'),
            'nroClientes' => request('nroClientes'),
            'nroMesa' => $tableID
        ]);

        $table = Table::find($tableID);
        $table->disponibilidad = 'no disponible';
        $table->save();

        return redirect('/reservas')->with('status', 'Se creo correctamente!'); 
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $reserva = Reserve::find($id);

        $table = Table::find($reserva->nroMesa);
        $table->disponibilidad = 'disponible';
        $table->save();

        $reserva->delete();

        return redirect('/reservas')->with('status', 'Se elimino correctamente!'); 
    }
}
