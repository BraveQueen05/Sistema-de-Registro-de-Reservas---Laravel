<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title>Laravel</title>

        <!-- Fonts -->
        <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous"><link href="">

    </head>
    <body>

    <div id="app">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h1>Listado de Reservas</h1>
                </div>
            </div>
            <?php if(session('status')): ?>
                <div class="alert alert-success" role="alert">
                  <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>
            <?php if(session('statusError')): ?>
                <div class="alert alert-danger" role="alert">
                  <?php echo e(session('statusError')); ?>

                </div>
            <?php endif; ?>
            <div style="margin-top: 30px; margin-bottom:30px;">
                <a href="<?php echo e(url('/reservas/create')); ?>" class="btn btn-primary active" role="button" aria-pressed="true">Crear Reserva</a>
            </div>
            <div class="row">
                <div class="col-lg-12">
                
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Código de Reserva</th>
                                <th>Nombre del Cliente</th>
                                <th>Nombre del Anfitrión</th>
                                <th>Número de Clientes</th>
                                <th>Número de Mesa</th>
                                <th>Fecha Creacion</th>
                                <th>Fecha Actualizacion</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $reservas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reserva): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td v-text="cliente.id"> <?php echo e($reserva->id); ?></td>
                                    <td v-text="cliente.clienteNombre"> <?php echo e($reserva->clienteNombre); ?> </td>
                                    <td v-text="cliente.hostNombre"> <?php echo e($reserva->hostNombre); ?> </td>
                                    <td v-text="cliente.nroClientes	"> <?php echo e($reserva->nroClientes); ?> </td>
                                    <td v-text="cliente.nroMesa"> <?php echo e($reserva->nroMesa); ?> </td>
                                    <td v-text="cliente.created_at "> <?php echo e($reserva->created_at); ?> </td>
                                    <td v-text="cliente.updated_at"> <?php echo e($reserva->updated_at); ?> </td>
                                    <td>
                                        <form method="POST" action="<?php echo e(route('reservas.destroy', $reserva->id)); ?>">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger">
                                                <i class="fa fa-trash" aria-hidden="true"></i>
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                
                </div>
            </div>
        </div>
    </div>

    </body>
</html><?php /**PATH D:\Flavia\Isil\3er Ciclo\final-figueroa\resources\views/reservas/index.blade.php ENDPATH**/ ?>